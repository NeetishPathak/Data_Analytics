README
Following Python files have been written for the project2

1.) project2_Task1.py
Description : This program is used to generate histograms and correlation matrix for Task1

2.) project2_Task2.py
Description : This program can be used to perform the linear regression in one variable as asked in task2. It prints out the statistical values on console 
			  displays the plots

3.) project2_Task2_polyfit
Description : This program is written to perform the polyfit part of Task 2 for linear regression in one variable. It prints out the statistical values
			  on console and displays the plot for 2nd order polyfit. It can be tested for 3rd order fit as well

4.) project2_UsinagPandasStats.pyDescription
Description : This program makes use of pandas.stats api to perform the regression analysis and prints out the result on the console

5.) ResidualAnalysisMultiVariateReg.py
Description : This program is written to perform the residual analysis for the multivariate linear regression 

