Read me document

The first task with fixed arrival, orbiting time is written in IOT_hw2_npathak2.py
and output is generated as output1.txt

It has the first arrival CLA value set to 2



______________________________________________________________________________________


The second task with randomized arrival, orbiting time is written in IOT_hw2_npathak2_task2.py
and output is generated as output2.txt

It has the first arrival CLA value set to 0 since the arrival is considered randomized
The seed is currently set to 2000 to generate the output2.txt

In case a different seed is to be used, please modify the line random.seed(seed_value) in the program

